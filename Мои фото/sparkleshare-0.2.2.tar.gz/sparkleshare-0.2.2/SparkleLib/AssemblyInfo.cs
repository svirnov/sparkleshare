/*
 * AssemblyInfo.cs
 *
 * This is free software. See COPYING for details.
 */

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("0.2.2")]
[assembly: AssemblyTitle ("SparkleShare")]
