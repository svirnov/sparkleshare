<?php

echo "<br><h3>".sprintf(_("[WARNING]: Menu Item: %s is disabled because asterisk is not running"),$name)."</h3><br><br>";
echo "<h5>"._("Restart Asterisk and then refresh the browser in order to try accessing this menu item again.")."</h5><br><br>";

?>
