<?php

/**
 * @file
 * version
 */

$ARI_VERSION = 'FreePBX 2.5';

?>
